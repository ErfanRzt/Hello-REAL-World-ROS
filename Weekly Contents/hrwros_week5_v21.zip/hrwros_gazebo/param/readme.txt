The file 'mux.yaml' was copied from the package 'turtlebot_bringup' (version: a66b6eaf). This was done to avoid a dependency on 'turtlebot_bringup', which would bring in an inordinate amount of dependencies for just a single file.

The package is licensed BSD.

Original author of mux.yaml: jorge
